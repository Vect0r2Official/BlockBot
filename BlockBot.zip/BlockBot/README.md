# BlockBot

Android portfolio project that launches the original Block Blast! Android app, keeps a persistent overlay alive, observes the game through Android MediaProjection, detects an 8×8 board plus the three current pieces, searches legal placements, and performs drag gestures through AccessibilityService.

## What is implemented

- One APK for the controller/overlay.
- Automatic launch of the installed original Block Blast! package: `com.block.juggle`.
- Persistent overlay: turning the bot OFF pauses automation without closing the overlay.
- Separate `×` exit button stops BlockBot services.
- MediaProjection screen capture.
- AccessibilityService gesture dispatch.
- Visual board/piece detection using Android Bitmap pixel sampling.
- Three-piece search with board simulation and survival-oriented heuristic.
- No rotation assumption, matching the documented classic ruleset.
- Resolution-independent geometry as a starting point, with ratios centralized in `VisionEngine.kt` and `BotEngine.kt` for calibration.

## Android requirements

- Android Studio with SDK 36 installed.
- JDK 17.
- Android 8.0+ device.
- The original Block Blast! app installed.
- Overlay permission enabled.
- BlockBot Accessibility Service enabled.
- Screen-capture permission granted each time Android asks.

## Build

Open the project folder in Android Studio and let Gradle sync. Then build the `app` module.

The development environment used to package this source did not have Android SDK/Gradle installed, so the APK itself is not included and the Gradle wrapper JAR is intentionally omitted. Android Studio will download the declared build tooling on sync.

## First run

1. Install BlockBot.
2. Open BlockBot.
3. Enable the BlockBot accessibility service.
4. Grant display-over-other-apps permission.
5. Press `START BLOCKBOT + BLOCK BLAST`.
6. Accept Android's screen-capture prompt.
7. BlockBot launches `com.block.juggle` and starts the overlay.
8. `ON/OFF` changes only automation state. `×` exits the bot.

## Important engineering note

The solver does not claim mathematical infinite survival for every possible random future-piece sequence. It optimizes the current three-piece sequence for line clearing, future mobility, empty space, large open areas, and low fragmentation. The visual detector is deliberately self-contained, but current Block Blast UI skins/device layouts can vary, so the board/tray ratios may need calibration on the target phone.

## Portfolio extensions

A polished v1.0 can add an in-app calibration screen, a deterministic simulator, replay logs, solver benchmarks, confidence overlays, and automatic recovery from animations or ads.
