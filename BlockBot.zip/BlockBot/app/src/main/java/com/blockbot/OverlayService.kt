package com.blockbot

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: View? = null
    private var engine: BotEngine? = null
    private var lastX = 0; private var lastY = 0; private var downX = 0f; private var downY = 0f
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply { setColor(Color.rgb(21,29,51)); cornerRadius = dp(18).toFloat() }
        }
        val title = TextView(this).apply {
            text = "BLOCKBOT  •  LIVE"
            textSize = 14f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        val status = TextView(this).apply {
            text = "Starting…"
            textSize = 11f
            setTextColor(Color.rgb(154,166,194))
            setPadding(0, dp(4), 0, dp(8))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val toggle = Button(this).apply {
            text = "ON"
            setOnClickListener {
                AppState.enabled.set(!AppState.enabled.get())
                text = if (AppState.enabled.get()) "ON" else "OFF"
                status.text = if (AppState.enabled.get()) "AI control resumed" else "AI paused • overlay stays" 
                engine?.setEnabled(AppState.enabled.get())
            }
        }
        val exit = Button(this).apply {
            text = "×"
            setOnClickListener {
                engine?.stop()
                stopService(Intent(this@OverlayService, ScreenCaptureService::class.java))
                stopSelf()
            }
        }
        row.addView(toggle, LinearLayout.LayoutParams(0, dp(42), 1f))
        row.addView(exit, LinearLayout.LayoutParams(dp(54), dp(42)))
        card.addView(title)
        card.addView(status)
        card.addView(row)
        card.setOnTouchListener { _, event -> drag(event) }
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        val params = WindowManager.LayoutParams(dp(220), WindowManager.LayoutParams.WRAP_CONTENT, type, flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12); y = dp(90)
        }
        root = card
        wm.addView(card, params)
        engine = BotEngine(this).also { it.start() }
    }
    private fun drag(event: MotionEvent): Boolean {
        val v = root ?: return false
        val p = v.layoutParams as WindowManager.LayoutParams
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; lastX = p.x; lastY = p.y; return true }
            MotionEvent.ACTION_MOVE -> { p.x = lastX - (event.rawX - downX).toInt(); p.y = lastY + (event.rawY - downY).toInt(); wm.updateViewLayout(v, p); return true }
            MotionEvent.ACTION_UP -> return false
        }
        return false
    }
    override fun onDestroy() {
        engine?.stop(); engine = null
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
