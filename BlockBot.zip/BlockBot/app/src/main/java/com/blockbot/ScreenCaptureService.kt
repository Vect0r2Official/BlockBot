package com.blockbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.view.WindowManager

class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        private const val CHANNEL = "blockbot_capture"
    }
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    override fun onCreate() {
        super.onCreate()
        createChannel()
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val data = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (resultCode == -1 || data == null) return START_NOT_STICKY
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) startForeground(17, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(17, notification)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val bounds = wm.currentWindowMetrics.bounds
        val width = bounds.width().coerceAtLeast(320)
        val height = bounds.height().coerceAtLeast(480)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).also { imageReader ->
            imageReader.setOnImageAvailableListener({ r ->
                val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val bmp = android.graphics.Bitmap.createBitmap(width + rowPadding / pixelStride, height, android.graphics.Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(buffer)
                    val cropped = if (bmp.width == width) bmp else android.graphics.Bitmap.createBitmap(bmp, 0, 0, width, height)
                    AppState.lastFrame.getAndSet(cropped)?.let { old -> if (old != cropped) old.recycle() }
                    if (cropped !== bmp) bmp.recycle()
                } finally {
                    image.close()
                }
            }, null)
            virtualDisplay = projection?.createVirtualDisplay("BlockBot", width, height, resources.displayMetrics.densityDpi, android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.surface, null, null)
        }
        AppState.lastStatus = "Screen capture running"
        return START_STICKY
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "BlockBot capture", NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun buildNotification(): Notification {
        val launch = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL).setContentTitle("BlockBot is running").setContentText("Screen analysis is active").setSmallIcon(com.blockbot.R.drawable.ic_blockbot).setContentIntent(launch).setOngoing(true).build()
        else Notification.Builder(this).setContentTitle("BlockBot is running").setContentText("Screen analysis is active").setSmallIcon(com.blockbot.R.drawable.ic_blockbot).setContentIntent(launch).setOngoing(true).build()
    }
    override fun onDestroy() {
        virtualDisplay?.release(); virtualDisplay = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        AppState.lastStatus = "Screen capture stopped"
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
