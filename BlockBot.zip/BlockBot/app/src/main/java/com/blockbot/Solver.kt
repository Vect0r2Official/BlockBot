package com.blockbot

import kotlin.math.max

object Solver {
    data class Decision(val pieceIndex: Int, val placement: Placement, val value: Double)
    fun choose(board: Board, pieces: List<Piece>): Decision? {
        if (pieces.isEmpty()) return null
        val used = BooleanArray(pieces.size)
        var best: SearchBest? = null
        dfs(board, pieces, used, 0, 0.0, null, null, bestHolder = { candidate ->
            if (best == null || candidate.value > best!!.value) best = candidate
        })
        return best?.decision
    }
    private data class SearchBest(val value: Double, val decision: Decision)
    private fun dfs(board: Board, pieces: List<Piece>, used: BooleanArray, depth: Int, value: Double, first: Decision?, firstBoard: Board?, bestHolder: (SearchBest) -> Unit) {
        if (depth == pieces.size) {
            if (first != null) bestHolder(SearchBest(value, first))
            return
        }
        var any = false
        for (i in pieces.indices) {
            if (used[i]) continue
            val piece = pieces[i]
            val placements = board.legalPlacements(piece)
            if (placements.isEmpty()) continue
            used[i] = true
            for (p in placements) {
                val result = board.placeAndClear(piece, p.row, p.col)
                val immediate = evaluate(result.board, result.clearedLines, pieces, used, i)
                val decision = first ?: Decision(i, p, immediate)
                dfs(result.board, pieces, used, depth + 1, value + immediate, decision, if (firstBoard == null) result.board else firstBoard, bestHolder)
                any = true
            }
            used[i] = false
        }
        if (!any && first != null) bestHolder(SearchBest(value - 100000.0, first))
    }
    private fun evaluate(board: Board, cleared: Int, pieces: List<Piece>, used: BooleanArray, placed: Int): Double {
        var future = 0
        for (i in pieces.indices) if (!used[i] || i == placed) future += board.mobility(pieces[i])
        val empty = board.emptyCount()
        val fragment = board.fragmentation()
        val square = board.largestEmptySquare()
        return cleared * 4000.0 + future * 35.0 + empty * 4.0 + square * 120.0 - fragment * 18.0
    }
}
