package com.blockbot

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.max

class BotEngine(private val context: Context) {
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private var task: ScheduledFuture<*>? = null
    @Volatile private var running = false
    @Volatile private var enabled = true
    private var lastBoardFingerprint = ""
    fun start() {
        if (running) return
        running = true
        task = executor.scheduleWithFixedDelay({ tick() }, 1200, 550, TimeUnit.MILLISECONDS)
    }
    fun setEnabled(v: Boolean) { enabled = v }
    fun stop() { running = false; task?.cancel(true); task = null; executor.shutdownNow() }
    private fun tick() {
        if (!running || !enabled) return
        val frame = AppState.lastFrame.get() ?: run { AppState.lastStatus = "Waiting for game screen"; return }
        val detection = runCatching { VisionEngine.analyze(frame) }.getOrNull() ?: run { AppState.lastStatus = "Searching for Block Blast board"; return }
        if (detection.confidence < 0.55) return
        val pieces = detection.pieces
        val board = detection.board
        val fingerprint = board.cells.joinToString("") + "|" + pieces.joinToString(";") { it.cells.joinToString(",") }
        if (fingerprint == lastBoardFingerprint) return
        val decision = Solver.choose(board, pieces) ?: run { AppState.lastStatus = "No legal move detected"; return }
        val piece = pieces[decision.pieceIndex]
        val cell = (minOf(detection.screenWidth * 0.88 / 8.0, detection.screenHeight * 0.47 / 8.0)).toInt()
        val boardSize = (detection.screenWidth * 0.88).toInt().coerceAtMost((detection.screenHeight * 0.47).toInt())
        val left = (detection.screenWidth - boardSize) / 2
        val top = (detection.screenHeight * 0.23).toInt()
        val tx = (left + (decision.placement.col + 0.5) * cell).toInt()
        val ty = (top + (decision.placement.row + 0.5) * cell).toInt()
        val service = BotAccessibilityService.instance ?: run { AppState.lastStatus = "Waiting for accessibility service"; return }
        AppState.lastStatus = "Dragging piece ${piece.id + 1} to ${decision.placement.row + 1},${decision.placement.col + 1}"
        val ok = service.drag(piece.sourceX, piece.sourceY, tx, ty, max(220L, (cell * 3L).coerceAtMost(380L)))
        if (ok) {
            AppState.moves++
            lastBoardFingerprint = fingerprint
            Handler(Looper.getMainLooper()).postDelayed({ AppState.lastStatus = "AI move sent • waiting for next state" }, 180)
        }
    }
}
