package com.blockbot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object VisionEngine {
    data class Detection(val board: Board, val pieces: List<Piece>, val confidence: Double, val screenWidth: Int, val screenHeight: Int)
    private data class Rect(val l: Int, val t: Int, val r: Int, val b: Int)
    fun analyze(src: Bitmap): Detection? {
        if (src.width < 400 || src.height < 600) return null
        val w = src.width
        val h = src.height
        val boardSize = min((w * 0.88).toInt(), (h * 0.47).toInt())
        val left = (w - boardSize) / 2
        val top = (h * 0.23).toInt()
        val cell = boardSize / 8f
        if (top + boardSize >= h) return null
        val bg = averageColor(src, Rect(left + 3, top + 3, left + boardSize - 3, top + boardSize - 3))
        val boardCells = IntArray(64)
        var occupied = 0
        for (r in 0..7) for (c in 0..7) {
            val cx = (left + (c + 0.5f) * cell).toInt()
            val cy = (top + (r + 0.5f) * cell).toInt()
            val sample = sampleAverage(src, cx, cy, max(3, (cell * 0.16f).toInt()))
            if (isBlock(sample, bg)) { boardCells[r * 8 + c] = 1; occupied++ }
        }
        val board = Board(boardCells)
        val trayY = (h * 0.84).toInt()
        val slotCenters = intArrayOf((w * 0.17).toInt(), (w * 0.50).toInt(), (w * 0.83).toInt())
        val pieces = ArrayList<Piece>()
        for (i in 0..2) {
            val piece = detectPiece(src, slotCenters[i], trayY, i, w, h)
            if (piece != null) pieces.add(piece)
        }
        if (pieces.size != 3) return null
        val confidence = (0.25 + if (occupied > 0) 0.25 else 0.0 + pieces.sumOf { it.cells.size }.coerceAtMost(9) / 9.0 * 0.5).coerceIn(0.0, 1.0)
        return Detection(board, pieces, confidence, w, h)
    }
    private fun detectPiece(src: Bitmap, cx: Int, cy: Int, id: Int, w: Int, h: Int): Piece? {
        val boxW = (w * 0.26).toInt()
        val boxH = (h * 0.15).toInt()
        val l = max(0, cx - boxW / 2)
        val t = max(0, cy - boxH / 2)
        val r = min(w - 1, cx + boxW / 2)
        val b = min(h - 1, cy + boxH / 2)
        val mask = Array(5) { BooleanArray(5) }
        val sx = (r - l) / 5f
        val sy = (b - t) / 5f
        var count = 0
        for (rr in 0..4) for (cc in 0..4) {
            val x = (l + (cc + 0.5f) * sx).toInt().coerceIn(0, w - 1)
            val y = (t + (rr + 0.5f) * sy).toInt().coerceIn(0, h - 1)
            val color = sampleAverage(src, x, y, max(2, min(sx, sy).toInt() / 5))
            val fg = isPieceColor(color)
            mask[rr][cc] = fg
            if (fg) count++
        }
        if (count == 0) return null
        var minR = 4; var maxR = 0; var minC = 4; var maxC = 0
        for (rr in 0..4) for (cc in 0..4) if (mask[rr][cc]) { minR = min(minR, rr); maxR = max(maxR, rr); minC = min(minC, cc); maxC = max(maxC, cc) }
        val cells = ArrayList<Int>()
        for (rr in minR..maxR) for (cc in minC..maxC) if (mask[rr][cc]) cells.add((rr - minR) * 5 + (cc - minC))
        if (cells.size !in 1..5) return null
        val sourceX = cx
        val sourceY = cy
        return Piece(cells.toIntArray(), sourceX, sourceY, id)
    }
    private fun isPieceColor(c: Int): Boolean {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        return hsv[1] > 0.45f && hsv[2] > 0.55f
    }
    private fun isBlock(c: Int, bg: Int): Boolean {
        val dr = abs(Color.red(c) - Color.red(bg))
        val dg = abs(Color.green(c) - Color.green(bg))
        val db = abs(Color.blue(c) - Color.blue(bg))
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        return (dr + dg + db) > 80 && hsv[1] > 0.35f && hsv[2] > 0.35f
    }
    private fun averageColor(b: Bitmap, rect: Rect): Int = sampleAverage(b, (rect.l + rect.r) / 2, (rect.t + rect.b) / 2, min(rect.r - rect.l, rect.b - rect.t) / 5)
    private fun sampleAverage(b: Bitmap, cx: Int, cy: Int, radius: Int): Int {
        var rr = 0L; var gg = 0L; var bb = 0L; var n = 0L
        val l = max(0, cx - radius); val t = max(0, cy - radius); val r = min(b.width - 1, cx + radius); val d = min(b.height - 1, cy + radius)
        var y = t
        while (y <= d) {
            var x = l
            while (x <= r) {
                val c = b.getPixel(x, y)
                rr += Color.red(c); gg += Color.green(c); bb += Color.blue(c); n++
                x += max(1, radius / 2)
            }
            y += max(1, radius / 2)
        }
        return Color.rgb((rr / n).toInt(), (gg / n).toInt(), (bb / n).toInt())
    }
}
