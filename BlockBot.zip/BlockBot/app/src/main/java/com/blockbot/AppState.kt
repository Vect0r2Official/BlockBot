package com.blockbot

import android.graphics.Bitmap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

object AppState {
    const val BLOCK_BLAST_PACKAGE = "com.block.juggle"
    const val ACTION_SET_BOT = "com.blockbot.SET_BOT"
    const val EXTRA_ENABLED = "enabled"
    val enabled = AtomicBoolean(true)
    val lastFrame = AtomicReference<Bitmap?>(null)
    @Volatile var lastStatus: String = "Waiting for screen capture"
    @Volatile var moves: Long = 0
    @Volatile var lines: Long = 0
    @Volatile var scoreEstimate: Long = 0
}
