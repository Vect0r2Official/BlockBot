package com.blockbot

import android.content.Context
import android.content.Intent
import android.widget.Toast

object GameLauncher {
    fun launch(context: Context) {
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(AppState.BLOCK_BLAST_PACKAGE)
        if (intent == null) {
            Toast.makeText(context, "Original Block Blast! is not installed", Toast.LENGTH_LONG).show()
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        context.startActivity(intent)
    }
}
