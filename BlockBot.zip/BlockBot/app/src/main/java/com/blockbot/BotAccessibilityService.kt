package com.blockbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: BotAccessibilityService? = null }
    override fun onServiceConnected() { super.onServiceConnected(); instance = this; AppState.lastStatus = "Accessibility ready" }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { AppState.lastStatus = "Accessibility interrupted" }
    override fun onDestroy() { instance = null; super.onDestroy() }
    fun drag(sx: Int, sy: Int, tx: Int, ty: Int, duration: Long = 260L): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        val path = Path().apply { moveTo(sx.toFloat(), sy.toFloat()); cubicTo(sx.toFloat(), sy.toFloat() - 40f, tx.toFloat(), ty.toFloat() + 40f, tx.toFloat(), ty.toFloat()) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, duration)).build()
        return dispatchGesture(gesture, null, null)
    }
}
