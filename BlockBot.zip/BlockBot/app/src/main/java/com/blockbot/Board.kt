package com.blockbot

import kotlin.math.max

class Board(val cells: IntArray = IntArray(64)) {
    fun copy(): Board = Board(cells.copyOf())
    fun isFree(r: Int, c: Int) = cells[r * 8 + c] == 0
    fun canPlace(piece: Piece, top: Int, left: Int): Boolean {
        for (p in piece.cells) {
            val r = top + (p / 5)
            val c = left + (p % 5)
            if (r !in 0..7 || c !in 0..7 || !isFree(r, c)) return false
        }
        return true
    }
    fun placeAndClear(piece: Piece, top: Int, left: Int): ResultState {
        val out = copy()
        for (p in piece.cells) out.cells[(top + p / 5) * 8 + left + p % 5] = 1
        var cleared = 0
        val clearRow = BooleanArray(8)
        val clearCol = BooleanArray(8)
        for (r in 0..7) {
            var full = true
            for (c in 0..7) if (out.cells[r * 8 + c] == 0) { full = false; break }
            clearRow[r] = full
            if (full) cleared++
        }
        for (c in 0..7) {
            var full = true
            for (r in 0..7) if (out.cells[r * 8 + c] == 0) { full = false; break }
            clearCol[c] = full
            if (full) cleared++
        }
        for (r in 0..7) for (c in 0..7) if (clearRow[r] || clearCol[c]) out.cells[r * 8 + c] = 0
        return ResultState(out, cleared)
    }
    fun legalPlacements(piece: Piece): List<Placement> {
        val result = ArrayList<Placement>()
        for (r in 0..7) for (c in 0..7) if (canPlace(piece, r, c)) result.add(Placement(r, c))
        return result
    }
    fun emptyCount(): Int = cells.count { it == 0 }
    fun mobility(piece: Piece): Int = legalPlacements(piece).size
    fun fragmentation(): Int {
        var isolated = 0
        for (r in 0..7) for (c in 0..7) if (isFree(r, c)) {
            var n = 0
            if (r > 0 && isFree(r - 1, c)) n++
            if (r < 7 && isFree(r + 1, c)) n++
            if (c > 0 && isFree(r, c - 1)) n++
            if (c < 7 && isFree(r, c + 1)) n++
            if (n <= 1) isolated++
        }
        return isolated
    }
    fun largestEmptySquare(): Int {
        var best = 0
        val dp = IntArray(64)
        for (r in 0..7) for (c in 0..7) {
            val i = r * 8 + c
            if (!isFree(r, c)) continue
            val a = if (r > 0) dp[(r - 1) * 8 + c] else 0
            val b = if (c > 0) dp[r * 8 + c - 1] else 0
            val d = if (r > 0 && c > 0) dp[(r - 1) * 8 + c - 1] else 0
            dp[i] = 1 + min3(a, b, d)
            best = max(best, dp[i])
        }
        return best
    }
    private fun min3(a: Int, b: Int, c: Int) = minOf(a, b, c)
}

data class Placement(val row: Int, val col: Int)
data class ResultState(val board: Board, val clearedLines: Int)
data class Piece(val cells: IntArray, val sourceX: Int, val sourceY: Int, val id: Int)
