package com.blockbot

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.Settings.Secure
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    companion object { private const val REQ_CAPTURE = 401 } 
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        refreshStatus()
    }
    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
            setBackgroundColor(Color.rgb(11,16,32))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "BLOCKBOT"
            textSize = 32f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        val subtitle = TextView(this).apply {
            text = "Autonomous Block Blast solver"
            textSize = 16f
            setTextColor(Color.rgb(154,166,194))
            setPadding(0, dp(4), 0, dp(22))
        }
        status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(Color.rgb(21,29,51))
        }
        val start = Button(this).apply {
            text = "START BLOCKBOT + BLOCK BLAST"
            setOnClickListener { startFlow() }
        }
        val access = Button(this).apply {
            text = "OPEN ACCESSIBILITY SETTINGS"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val overlay = Button(this).apply {
            text = "OPEN OVERLAY PERMISSION"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val info = TextView(this).apply {
            text = "The app launches the installed original Block Blast! app (com.block.juggle), keeps the bot overlay alive, captures the game screen with MediaProjection, and sends drag gestures through AccessibilityService. OFF pauses automation without closing the overlay."
            textSize = 14f
            setTextColor(Color.rgb(154,166,194))
            setPadding(0, dp(20), 0, 0)
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(status)
        addGap(content, 14)
        content.addView(start)
        addGap(content, 8)
        content.addView(access)
        addGap(content, 8)
        content.addView(overlay)
        content.addView(info)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }
    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable overlay permission first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Enable BlockBot accessibility service first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        val pm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(pm.createScreenCaptureIntent(), REQ_CAPTURE)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE || resultCode != RESULT_OK || data == null) return
        startService(Intent(this, OverlayService::class.java))
        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
        GameLauncher.launch(this)
        Toast.makeText(this, "BlockBot started", Toast.LENGTH_SHORT).show()
        refreshStatus()
    }
    override fun onResume() { super.onResume(); if (::status.isInitialized) refreshStatus() }
    private fun refreshStatus() {
        if (!::status.isInitialized) return
        val overlay = if (Settings.canDrawOverlays(this)) "OK" else "MISSING"
        val access = if (isAccessibilityEnabled()) "OK" else "MISSING"
        status.text = "Overlay permission: $overlay\nAccessibility: $access\nBot: ${if (AppState.enabled.get()) "ON" else "OFF"}\n${AppState.lastStatus}"
    }
    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Secure.getString(contentResolver, Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val expected = ComponentName(this, BotAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }
    private fun addGap(parent: ViewGroup, h: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
